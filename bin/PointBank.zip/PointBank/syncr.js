var Syncr = function(){
	var functions = [];
	
	this.add = function(func){
	
	};
	
	this.execute = function(callback){
		if (callback) callback();
	};
}

module.exports = new Syncr();